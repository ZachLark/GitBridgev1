# This script reads figma_invites.json, filters for pending invites,
# and logs or triggers a webhook per invite. For use in GBP19.
